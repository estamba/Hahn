﻿using Hahn.ApplicatonProcess.December2020.Domain.Interfaces.Data;
using Hahn.ApplicatonProcess.December2020.Web.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApplicantController : ControllerBase
    {
        private readonly IApplicantService applicantService;

        public ApplicantController(IApplicantService applicantService)
        {
            this.applicantService = applicantService;
        }



       

        [HttpPost]
        public IActionResult Add(ApplicantViewModel applicant)
        {


            if (!ModelState.IsValid)
                return BadRequest("");

            var result = applicantService.AddApplicant(applicant.ToApplicant());

            return Created("", new { url = GenerateUrl(result.ID) });
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="id" example="1"></param>
        /// <returns></returns>
        [HttpGet("{id:int}")]
        public IActionResult Get(int id)
        {
            var result = applicantService.GetApplicant(id);
            if (result.Data is null)
                return NotFound();
            return Ok(result.Data);

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id" example= "1"></param>
        /// <returns></returns>
        [HttpDelete("{id:int}")]
        public IActionResult Delete(int id)
        {
            var results = applicantService.DeleteApplicant(id);
            if (results.IsSuccessful)
                return Ok();
            return BadRequest(results.Data);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id" example= "1"></param>
        /// <param name="requestBody"></param>
        /// <returns></returns>
        
        [HttpPut("{id:int}")]
        public IActionResult Update(int id, [FromBody] ApplicantViewModel requestBody)
        {
            var result = applicantService.GetApplicant(id);
            if (!result.IsSuccessful)

                return BadRequest($"applicant does not exist");

            var applicant = requestBody.ToApplicant();
            applicant.ID = id;
            applicantService.UpdateApplicantInfo(applicant);

            return Ok();
        }
        private string GenerateUrl(int applicantId)
        {

            return $"{Request.Scheme}://{Request.Host}/api/applicant/{applicantId}";
        }
    }
}
