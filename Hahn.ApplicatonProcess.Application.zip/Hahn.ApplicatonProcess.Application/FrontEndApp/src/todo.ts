export class Todo
{

  public  done = false;
  public description= "";
 
}
