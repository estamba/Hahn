﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hahn.ApplicatonProcess.December2020.Domain.Models
{
    public class Result<T>
    {
        public bool IsSuccessful { get; set; }
        public T Data { get; set; }


        public static Result<T> Successful(T data)
        {
            return new Result<T>() { Data = data, IsSuccessful = true};

        }

        public static Result<T> Failed(T data)
        {
            return new Result<T>() { Data = data, IsSuccessful = false };
        }
    }
}
