import { applicant } from '../Models/applicant';
import {HttpClient, json} from 'aurelia-fetch-client';
import {config} from 'config'

let httpClient = new HttpClient();

export class ApiService {
 
  postData(applicant:applicant):Promise<any> {
   return  httpClient.fetch(config.url, {
       method: "POST",
       body: JSON.stringify(applicant)
    })
  
    .then(response => {
      if (!response.ok) {
        throw new Error(response.statusText)
      }
      return response.json()
    })
    .then(data => {
      return data
    })
    .catch((error: Error) => {
      console.log(error);
      throw error 
    })
    
       
    
 }
}

