﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Web.Middleware
{
  
    public class RequestLogger
    {
        private readonly RequestDelegate next;
        private readonly ILogger<RequestLogger> logger;

        public RequestLogger(RequestDelegate next, ILogger<RequestLogger> logger)
        {
           this. next = next;
            this.logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                logger.LogInformation($"Starting request to {context.Request?.Path.Value} of type {context.Request.Method}");
                await next(context);
            }
            finally
            {
                logger.LogInformation($"Request {context.Request?.Method} { context.Request?.Path.Value} => {context.Response?.StatusCode}");
                    
            }
        }
    }
}
