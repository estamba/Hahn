﻿using Hahn.ApplicatonProcess.December2020.Domain.Interfaces.Data;
using Hahn.ApplicatonProcess.December2020.Domain.Interfaces.Services;
using Hahn.ApplicatonProcess.December2020.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain.Services
{
 
    public class ApplicantService : IApplicantService
    {
        private readonly IApplicantRepository applicantRepository;

        public ApplicantService(IApplicantRepository applicantRepository)
        {
            this.applicantRepository = applicantRepository;
        }
        public Applicant AddApplicant(Applicant applicant)
        {

            applicant.ID = applicantRepository.GetLastApplicantID() + 1;
           return applicantRepository.Add(applicant);

        }


        public Result<string> DeleteApplicant(int applicantId)
        {

            return applicantRepository.Remove(applicantId);
        }

        public Result<Applicant> GetApplicant(int applicantId)
        {

            var applicant = applicantRepository.GetyId(applicantId);
            if (applicant is null) return Result<Applicant>.Failed(default(Applicant)) ;

            return Result<Applicant>.Successful(applicant);
        }

        public Applicant UpdateApplicantInfo(Applicant applicant)
        {

            return applicantRepository.Update(applicant);
        }
    }
}
