﻿using Hahn.ApplicatonProcess.December2020.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hahn.ApplicatonProcess.December2020.Interfaces.Domain
{
    public interface IApplicantService
    {
        Result<int> AddApplicant(Applicant applicant);
        Result<string> DeleteApplicant(int applicantId);
        Result<Applicant> GetApplicant(string applicantId);
        Result<Applicant> UpdateApplicantInfo(Applicant applicant);

    }
}
