import { I18N } from 'aurelia-i18n';
import { inject } from 'aurelia-dependency-injection';
import {applicant} from './models/applicant' 
import { PLATFORM } from 'aurelia-pal';
import { RouterConfiguration, Router } from "aurelia-router";

@inject(I18N)
export class App {
  i18n:I18N;
 router:Router;

  constructor(i18n:I18N){

    this.i18n = i18n;
    console.log(this.i18n);
    this.i18n
      .setLocale('de-DE')
		
      .then( () => {
         console.log('Locale is ready!');
      });
  }

  
  


  configureRouter(config: RouterConfiguration, router: Router){
    this.router = router
    config.options.pushState = true;
    config.map([

      {route: '', name:'home', moduleId: PLATFORM.moduleName('applicant'), title: 'home'},
      {route: 'success', name:'success', moduleId: PLATFORM.moduleName('success'), title: 'success'},
      {route: 'error', name:'error', moduleId: PLATFORM.moduleName('error'), title: 'error'},

    ])

     
  }


 
}
