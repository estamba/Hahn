﻿using Hahn.ApplicatonProcess.December2020.Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Data
{
   public class ApplicationProcessDbContext: DbContext
    {
        public ApplicationProcessDbContext(DbContextOptions dbContextOptions):base(dbContextOptions)
        {

        }

   
        public DbSet<Applicant> Applicant { get; set; }
    }
}
