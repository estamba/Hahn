export class Success {
  message: string;

  constructor() {
    this.message = 'Hello world';
  }
}
