import { applicant } from '../models/applicant';
import {inject} from 'aurelia-framework';
import {DialogController} from 'aurelia-dialog';

@inject(DialogController)
export class Prompt {
 
  applicant: applicant
   controller : DialogController;
  constructor( controller: DialogController) {
    this.controller = controller;

    controller.settings.centerHorizontalOnly = true;
 }
 activate(applicant) {
    this.applicant = applicant;
 }
}
