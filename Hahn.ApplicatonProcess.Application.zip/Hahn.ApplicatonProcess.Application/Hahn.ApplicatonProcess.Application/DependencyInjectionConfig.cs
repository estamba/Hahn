﻿using Hahn.ApplicatonProcess.December2020.Data;
using Hahn.ApplicatonProcess.December2020.Domain.Interfaces.Data;
using Hahn.ApplicatonProcess.December2020.Domain.Interfaces.Services;
using Hahn.ApplicatonProcess.December2020.Domain.Services;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Web
{
    public static class DependencyInjectionConfig
    {
        public static IServiceCollection RegisterServices(this IServiceCollection services)
        {
            services.AddTransient<IApplicantService, ApplicantService>();
            services.AddTransient<IApplicantRepository, ApplicantRepository>();

            return services;
        }
    }
}
