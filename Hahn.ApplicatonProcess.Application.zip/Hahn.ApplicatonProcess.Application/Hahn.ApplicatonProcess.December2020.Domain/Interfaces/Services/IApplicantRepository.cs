﻿using Hahn.ApplicatonProcess.December2020.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain.Interfaces.Services
{
    public interface IApplicantRepository
    {

        Applicant  GetyId(int Id);
        Applicant Update(Applicant applicant);

        Result<string> Remove(int Id);

        Applicant Add(Applicant applicant);
        int GetLastApplicantID();
    }
}
