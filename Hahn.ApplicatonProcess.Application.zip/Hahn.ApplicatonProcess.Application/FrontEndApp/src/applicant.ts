import { Error } from './modals/error';
import { Router } from 'aurelia-router';
import { ApiService } from './data/apiService';
import { Prompt } from './modals/prompt';
import { applicant  } from './models/applicant';
import {inject, NewInstance} from 'aurelia-dependency-injection';
import {ValidationRules, ValidationControllerFactory, ValidationController, validateTrigger} from 'aurelia-validation'
import {BootstrapFormRenderer} from 'bootstrap-form-render';
import {DialogService} from 'aurelia-dialog';




@inject(NewInstance.of(ValidationController), DialogService, ApiService,Router)
export class Applicant {
  message: string;
 controller : ValidationController;
 applicant: applicant;
 dialogService:DialogService
 applicantService : ApiService;
 router:Router;
  constructor(controller :ValidationController, dialogService: DialogService, applicantService:ApiService,router:Router) {


    this.controller  = controller
   this.applicant = new applicant();
   this.dialogService = dialogService;
this.applicantService= applicantService;
this.router = router;

    this.controller.addRenderer(new BootstrapFormRenderer());
   
  

    this.addValidationRules();

  
  }
  addApplicant(){
    
    this.controller.validate()
    .then(result => {
      if (result.valid) {
        // validation succeeded
        console.log(this.applicant);
        this.applicantService.postData(this.applicant).then(()=>{

        console.log(this.applicant);

        this.router.navigateToRoute('success');
  
         }).catch((error)=>{
          // console.log(error);
           
          // this.router.navigateToRoute("error");
          this.dialogService.open( {viewModel: Error, model: 'sorry, there was an error processing your request' }).whenClosed(response => {
     
               this.applicant = null
            
         });

         });
      } 
    });
  
  }

  addValidationRules(){
    ValidationRules.ensure('name').required().minLength(5).withMessage('must be at least 5 characters!')
    .ensure('familyName').required().minLength(5).withMessage('must be at least 5 characters!')
   .ensure('address').required().minLength(10).withMessage('must be at least 10 characters!')
    .ensure('countryOfOrigin').required()
    .ensure('emailAddress').required().email()
    .ensure('age').required().range(20,60).withMessage('age must be between 20 to 60')
    .on(this.applicant);
  }
  OnReset(){
    this.dialogService.open( {viewModel: Prompt, model: this.applicant }).whenClosed(response => {
     
      console.log(response);
      console.log("here");
   
      if (!response.wasCancelled) {
         this.applicant = null
      } else {
        
        

         
      }
    
      
   });
  }
  get CanDisableButton(){
    if(this.applicant === null) 
    return true;

  var ressult =  Object.values(this.applicant).every(o => o === null || o === '' || o == undefined);
    return ressult;
  }

 


    
 
   
  

}

