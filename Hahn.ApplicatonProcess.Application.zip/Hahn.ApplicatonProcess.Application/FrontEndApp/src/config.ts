export const config = {
  url: 'https://localhost:5001/api/applicant'
}
