﻿using Hahn.ApplicatonProcess.December2020.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain.Interfaces.Data
{
    public interface IApplicantService
    {
        Applicant AddApplicant(Applicant applicant);
        Result<string> DeleteApplicant(int applicantId);
       Result<Applicant> GetApplicant(int applicantId);
        Applicant UpdateApplicantInfo(Applicant applicant);
    }
}
