export class Error {
  message: string;

  constructor() {
    this.message = 'Hello world';
  }
}
