﻿using Hahn.ApplicatonProcess.December2020.Domain.Interfaces.Services;
using Hahn.ApplicatonProcess.December2020.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Data
{
    public class ApplicantRepository : IApplicantRepository
    {
        private readonly ApplicationProcessDbContext dbContext;

        public ApplicantRepository(ApplicationProcessDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public Applicant Add(Applicant applicant)
        {

            dbContext.Applicant.Add(applicant);
            dbContext.SaveChanges();
            return applicant;


        }

        public Applicant GetyId(int Id)
        {

            return dbContext.Applicant.Find(Id);

        }

        public Result<string> Remove(int Id)
        {
          var applicant =  dbContext.Applicant.Find(Id);
            if (applicant is null) return Result<string>.Failed($"Applicant {Id} is not found");

            dbContext.Applicant.Remove(applicant);

            dbContext.SaveChanges();
            return Result<string>.Successful($"Applicant {Id} has been deleted");
        }

        public Applicant Update(Applicant updatedApplicant)
        {
            var applicant = dbContext.Applicant.Find(updatedApplicant.ID);
            applicant = updatedApplicant;
            dbContext.SaveChanges();
            return applicant;
        }
        public int GetLastApplicantID()
        {
           var results= dbContext.Applicant.OrderByDescending(a => a.ID).FirstOrDefault();

            if (results is null)
                return 0;

            return results.ID;
        }
    }
}
