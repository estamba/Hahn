﻿using Hahn.ApplicatonProcess.December2020.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Web.Models
{


    public class ApplicantViewModel
    {
        
        ///<example>Anthony</example>
        public string Name { get; set; }
        ///<example> Robinson Jnr.</example>

        public string FamilyName { get; set; }
        ///<example>560, State Street </example>

        public string Address { get; set; }
        ///<example> johndoe@gmail.com</example>

        public string EMailAdress { get; set; }
        ///<example> 24</example>

        public int Age { get; set; }
        ///<example>Senegal</example>

        public string CountryOfOrigin { get; set; }
        ///<example> true</example>

        public bool Hired
        {
            get; set;
        }
        public  Applicant ToApplicant()
        {

            return new Applicant()
            {
                Hired = Hired,
                Address = Address,
                Age = Age,
                EMailAdress = EMailAdress,
                FamilyName = FamilyName,
                Name = Name
            };

        }

    }
}
