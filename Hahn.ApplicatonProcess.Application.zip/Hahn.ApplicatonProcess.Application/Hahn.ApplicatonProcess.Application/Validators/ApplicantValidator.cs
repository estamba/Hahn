﻿using FluentValidation;
using Hahn.ApplicatonProcess.December2020.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Web.Validators
{
    public class ApplicantValidator: AbstractValidator<ApplicantViewModel>
    {
        public ApplicantValidator()
        {
            RuleFor(a => a.Name).MinimumLength(5).WithMessage("Name must contain at least 5 characters");
            RuleFor(a => a.FamilyName).MinimumLength(5).WithMessage("Family name must contain at least 5 characters");
            RuleFor(a => a.Address).MinimumLength(10).WithMessage("Address must contain at least 10 characters");
            RuleFor(a => a.EMailAdress).EmailAddress(FluentValidation.Validators.EmailValidationMode.AspNetCoreCompatible);
            RuleFor(a => a.Age).GreaterThan(19).LessThan(61).WithMessage("Age must be between 20 to 60");

            RuleFor(a => a.CountryOfOrigin).MustAsync(async (country, cancellation) =>
             {
                 return await IsCountryValidAsync(country);
             }).WithMessage("Invalid country name");



        }
        static async Task<bool> IsCountryValidAsync(string name)
        {
            var url = $"https://restcountries.eu/rest/v2/name/{name}?fullText=true";
            using(HttpClient client = new HttpClient())
            {
                var response = await client.GetAsync(url);
                return response.IsSuccessStatusCode;

            }
        }
    }
}
