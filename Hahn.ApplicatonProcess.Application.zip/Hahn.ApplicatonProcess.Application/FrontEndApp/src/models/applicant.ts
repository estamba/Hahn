import { ValidationRules } from "aurelia-validation";

export class applicant{

  public name : string 
  public familyName : string 
  public address : string;
  public countryOfOrigin : string;
  public emailAddress : string;
  public age : number;
  public hired: boolean;
  
}
