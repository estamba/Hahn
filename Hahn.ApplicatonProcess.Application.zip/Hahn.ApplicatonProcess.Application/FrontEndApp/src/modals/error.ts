import { inject } from 'aurelia-dependency-injection';
import { DialogController } from "aurelia-dialog";

@inject(DialogController)

export class Error {
  message: string;

  controller : DialogController;
  constructor( controller: DialogController) {
    this.controller = controller;

    controller.settings.centerHorizontalOnly = true;
  }
  activate(message){
    this.message = message;
  }
}
